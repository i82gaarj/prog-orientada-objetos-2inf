#ifndef PERSONA_H
#define PERSONA_H

#include <string>

using namespace std;

class Persona{

private:
	int edad_;

	string dni_, nombre_, apellidos_, direccion_, localidad_, provincia_, pais_;

public:
	Persona(string dni, string nombre = "", string apellidos = "", int edad = 0, string direccion = "", string localidad = "", string provincia = "", string pais = "");

	bool setEdad(int edad);

	bool mayor();


	inline string getDNI(){
		return dni_;
	}

	inline int getEdad(){
		return edad_;
	}

	inline string getNombre(){
		return nombre_;
	}

	inline string getApellidos(){
		return apellidos_;
	}

	inline string getApellidosyNombre(){
		return apellidos_ + ", " + nombre_;
	}

	inline string getDireccion(){
		return direccion_;
	}

	inline string getLocalidad(){
		return localidad_;
	}

	inline string getProvincia(){
		return provincia_;
	}

	inline string getPais(){
		return pais_;
	}

	inline void setDNI(string dni){
		dni_ = dni;
	}

	inline void setNombre(string nombre){
		nombre_ = nombre;
	}

	inline void setApellidos(string apellidos){
		apellidos_ = apellidos;
	}

	inline void setDireccion(string direccion){
		direccion_ = direccion;
	}

	inline void setLocalidad(string localidad){
		localidad_ = localidad;
	}

	inline void setProvincia(string provincia){
		provincia_ = provincia;
	}

	inline void setPais(string pais){
		pais_ = pais;
	}
};

#endif