#ifndef JUGADOR_H
#define JUGADOR_H

#include "persona.h"
#include <string>
#include <list>

using namespace std;

struct apuesta{
	int tipo;
	string valor;
	int cantidad;
};

class Jugador: public Persona{
private:
	int dinero_;
	string codigo_;
	list <apuesta> apuestas_;

public:
	Jugador(string dni, string codigo, string nombre = "", string apellidos = "", int edad = 0, string direccion = "", string localidad = "", string provincia = "", string pais = ""):Persona(dni, nombre, apellidos, edad, direccion, localidad, provincia, pais){
		codigo_ = codigo;
	}

	inline string getCodigo(){
		return codigo_;
	}

	inline void setCodigo(string codigo){
		codigo_ = codigo;
	}

	inline void setDinero(int dinero){
		dinero_ = dinero;
	}

	inline list <apuesta> getApuestas(){
		return apuestas_;
	}

	inline void setApuestas(){
		
	}
};

#endif