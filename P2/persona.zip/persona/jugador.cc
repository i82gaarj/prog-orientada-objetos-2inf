#include "jugador.h"


Jugador::Jugador(){
	dinero_ = 1000;
}